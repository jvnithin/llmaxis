import Hero from "@/components/sections/Hero";
import CaseStudies from "@/components/sections/CaseStudies";
import Testimonials from "@/components/sections/Testimonials";
import LeadForm from "@/components/sections/LeadForm";
import CTA from "@/components/sections/CTA";
import Programs from "@/components/sections/programs";
import HowLearningWorks from "@/components/sections/HowLearningWorks";
import Features from "@/components/sections/Features";
import Process from "@/components/sections/Process";


export const metadata = {
  title: "AI Bootcamp & Real-World Projects",
  description:
    "Join LLM Axis to learn AI through real-world projects, mentorship, and career guidance.",
};

export default function Home() {
  return (
    <>
      <Hero />
     <HowLearningWorks />
      <Programs />
      <Features />
      <CaseStudies />
      <Testimonials />
      <LeadForm />
      <CTA />
    </>
  );
}