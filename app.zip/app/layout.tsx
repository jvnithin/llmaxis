import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export const metadata = {
  metadataBase: new URL("https://llmaxis.in"),
  title: {
    default: "LLM Axis - AI Learning & Product Development",
    template: "%s | LLM Axis",
  },
  description:
    "Learn AI by building real-world projects. Join LLM Axis to become job-ready with expert mentorship and hands-on experience.",
  keywords: [
    "AI course",
    "AI bootcamp India",
    "learn artificial intelligence",
    "full stack AI",
    "AI projects",
  ],
  openGraph: {
    title: "LLM Axis",
    description:
      "Build real-world AI projects and become job-ready with LLM Axis.",
    url: "https://llmaxis.in",
    siteName: "LLM Axis",
    images: [
      {
        url: "/og-image.png", // add later
        width: 1200,
        height: 630,
      },
    ],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "LLM Axis",
    description:
      "Build real-world AI projects and become job-ready.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main className="pt-20">{children}</main>
        <Footer />
      </body>
    </html>
  );
}