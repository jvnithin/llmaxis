"use client";

import { useState } from "react";

export default function ContactPage() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const formData = new URLSearchParams();
    formData.append("name", form.name);
    formData.append("email", form.email);
    formData.append("phone", form.phone);
    formData.append("message", form.message);

    fetch(
      "https://script.google.com/macros/s/AKfycbyXznTHcPnIVnDI12XrcnOSsan1fs6FqUMlHXhySpgX6UOOScdzWTxzKVzf-gVWpHRc/exec",
      {
        method: "POST",
        body: formData,
        mode: "no-cors", // 🔥 REQUIRED FOR GOOGLE SCRIPT
      }
    )
      .then(() => {
        alert("Submitted successfully ✅");

        setForm({
          name: "",
          email: "",
          phone: "",
          message: "",
        });
      })
      .catch((error) => {
        console.error(error);
        alert("Submission failed ❌");
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <section className="min-h-screen bg-[#F7F8FC] flex items-center justify-center px-4 md:px-6 py-16">
      <div className="bg-white rounded-3xl p-6 md:p-10 max-w-5xl w-full shadow-sm grid md:grid-cols-2 gap-6 md:gap-10">

        {/* LEFT */}
        <div className="flex flex-col justify-center">
          <h2 className="text-2xl md:text-3xl font-bold text-[#0F172A] leading-tight">
            Hire Industry-Ready{" "}
            <span className="bg-gradient-to-r from-purple-600 to-indigo-600 text-transparent bg-clip-text">
              AI Talent
            </span>
          </h2>

          <p className="text-gray-500 mt-3 text-sm md:text-base leading-relaxed">
            Access a pre-vetted pool of AI engineers trained on real-world projects.
          </p>

          <div className="mt-5 flex gap-3 flex-wrap">
            <button className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-5 py-2 rounded-full text-sm">
              Book Call
            </button>
            <button className="border px-5 py-2 rounded-full text-sm">
              View Skills
            </button>
          </div>
        </div>

        {/* RIGHT FORM */}
        <form onSubmit={handleSubmit} className="space-y-4">

          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full border border-gray-300 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Name"
            required
          />

          <input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full border border-gray-300 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Email"
            required
          />

          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full border border-gray-300 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Phone"
          />

          <textarea
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            className="w-full border border-gray-300 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Message"
          />

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 rounded-lg text-sm font-medium"
          >
            {loading ? "Submitting..." : "Submit Request"}
          </button>

        </form>

      </div>
    </section>
  );
}