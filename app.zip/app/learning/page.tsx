import Link from "next/link";
import { Brain, Code2, Workflow, Database } from "lucide-react";
import Image from "next/image";

const features = [
  {
    title: "Python Foundations",
    desc: "Learn through hands-on projects and real applications.",
    icon: <Code2 className="text-purple-600 w-5 h-5" />,
  },
  {
    title: "AI Pipeline Development",
    desc: "Build scalable AI workflows and pipelines.",
    icon: <Workflow className="text-purple-600 w-5 h-5" />,
  },
  {
    title: "Working with LLMs",
    desc: "Master prompts, APIs, and AI integrations.",
    icon: <Brain className="text-purple-600 w-5 h-5" />,
  },
  {
    title: "Full-Stack AI Development",
    desc: "Develop full AI-powered applications.",
    icon: <Code2 className="text-purple-600 w-5 h-5" />,
  },
  {
    title: "Real-World AI Projects",
    desc: "Apply learning through real industry projects.",
    icon: <Database className="text-purple-600 w-5 h-5" />,
  },
];

export default function LearningPage() {
  return (
    <section className="min-h-screen bg-[#F7F8FC] px-4 md:px-6 py-16 text-center">

      {/* HEADING */}
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-bold text-[#0F172A] leading-tight">
          Agentic AI
          <br />
          <span className="bg-gradient-to-r from-purple-600 to-indigo-600 text-transparent bg-clip-text">
            Full-Stack Course
          </span>
        </h1>

        <p className="text-[#64748B] mt-5 text-sm md:text-lg leading-relaxed">
          Master the skills required to build intelligent AI applications — from Python foundations to deploying real-world AI systems.
        </p>

        {/* TAGS */}
        <div className="flex justify-center gap-4 mt-5 text-xs md:text-sm text-gray-500 flex-wrap">
          <span className="bg-white px-3 py-1 rounded-full shadow-sm">✔ Beginner Friendly</span>
          <span className="bg-white px-3 py-1 rounded-full shadow-sm">✔ Real-World Projects</span>
          <span className="bg-white px-3 py-1 rounded-full shadow-sm">✔ Full-Stack Development</span>
        </div>

        {/* CTA */}
        <div className="mt-6">
          <button className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-2.5 rounded-full text-sm font-medium shadow-md hover:opacity-90 transition">
            Enroll Now
          </button>
        </div>
      </div>

      {/* FEATURES */}
      <div className="grid md:grid-cols-3 gap-6 mt-14 max-w-5xl mx-auto">

        {features.map((item, i) => (
          <div
            key={i}
            className="bg-white p-6 rounded-xl border border-gray-100 text-left flex gap-4 items-start hover:shadow-lg hover:-translate-y-1 transition duration-300"
          >
            {/* ICON */}
            <div className="w-10 h-10 flex items-center justify-center bg-gradient-to-r from-purple-100 to-indigo-100 rounded-lg">
              {item.icon}
            </div>

            {/* TEXT */}
            <div>
              <h3 className="font-semibold text-[#0F172A]">
                {item.title}
              </h3>
              <p className="text-sm text-gray-500 mt-1 leading-relaxed">
                {item.desc}
              </p>
            </div>
          </div>
        ))}

      </div>

      {/* BOTTOM CTA */}
      <div className="mt-12 flex justify-center gap-4 flex-wrap">
        <Link
          href="/contact"
          className="bg-purple-600 text-white px-6 py-2.5 rounded-full text-sm font-medium shadow-md"
        >
          Explore Program
        </Link>
        <Link
          href="/contact"
          className="border border-gray-300 px-6 py-2.5 rounded-full text-sm font-medium hover:bg-gray-100 transition"
        >
          Learn More
        </Link>
      </div>

    </section>
  );
}