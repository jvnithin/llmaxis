export default function HirePage() {
  return (
    <section className="min-h-screen bg-[#F7F8FC] flex items-center justify-center px-4 md:px-6 py-16">

      <div className="bg-white rounded-3xl p-6 md:p-10 max-w-5xl w-full shadow-sm grid md:grid-cols-2 gap-4 md:gap-10">

        {/* LEFT */}
        <div className="flex flex-col justify-center">
          <h2 className="text-2xl md:text-3xl font-bold text-[#0F172A] leading-tight">
            Hire Industry-Ready{" "}
            <span className="bg-gradient-to-r from-purple-600 to-indigo-600 text-transparent bg-clip-text">
              AI Talent
            </span>
          </h2>

          <p className="text-gray-500 mt-3 text-sm md:text-base leading-relaxed">
            Access a pre-vetted pool of AI engineers trained on real-world projects.
          </p>

          <div className="mt-5 flex gap-3 flex-wrap">
            <button className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-5 py-2 rounded-full text-sm">
              Book Call
            </button>
            <button className="border px-5 py-2 rounded-full text-sm">
              View Skills
            </button>
          </div>
        </div>

        {/* RIGHT FORM */}
        <div className="space-y-4">

          <input
            className="w-full border border-gray-300 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Company Name"
          />

          <input
            className="w-full border border-gray-300 p-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Work Email"
          />
          <div>
            <label htmlFor="hiring-interest" className="text-xs text-gray-500">Hiring Interest</label>
            <select id="hiring-interest" className="w-full border border-gray-300 p-3 rounded-lg mt-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
              <option>AI Engineer</option>
              <option>Full Stack Developer</option>
              <option>Data Scientist</option>
            </select>
          </div>

          <button className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 rounded-lg text-sm font-medium">
            Submit Request
          </button>

        </div>

      </div>

    </section>
  );
}