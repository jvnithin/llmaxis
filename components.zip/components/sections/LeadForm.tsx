"use client";

import { useState } from "react";

export default function LeadForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [loading, setLoading] = useState(false);

  // Handle input changes
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  // ✅ FINAL SUBMIT HANDLER (GET METHOD)
  const handleSubmit = async () => {
    if (!form.name || !form.email || !form.phone) {
      alert("Please fill all required fields");
      return;
    }

    setLoading(true);

    try {
      const url = `https://script.google.com/macros/s/AKfycbzUI1Ne_VBnQRoh0A6wiJ96Ry3eLTF-0_1pty0GXsCMN3E6EKiDz-dt4pxWYrWkKELXmA/exec?name=${encodeURIComponent(
        form.name
      )}&email=${encodeURIComponent(form.email)}&phone=${encodeURIComponent(
        form.phone
      )}&message=${encodeURIComponent(form.message)}`;

      await fetch(url); // ✅ simple GET request

      alert("Submitted successfully!");

      setForm({
        name: "",
        email: "",
        phone: "",
        message: "",
      });
    } catch (error) {
      console.error(error);
      alert("Something went wrong");
    }

    setLoading(false);
  };

  return (
    <section className="py-24 bg-white">
      <div className="max-w-xl mx-auto px-6 text-center">

        <h2 className="text-3xl md:text-4xl font-bold">
          Get Free Career Consultation
        </h2>

        <p className="text-gray-500 mt-4">
          Talk to our experts and get a personalized roadmap.
        </p>

        <div className="mt-8 space-y-4">

          <input
            type="text"
            name="name"
            placeholder="Name"
            value={form.name}
            onChange={handleChange}
            className="w-full border px-4 py-3 rounded-lg"
          />

          <input
            type="email"
            name="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
            className="w-full border px-4 py-3 rounded-lg"
          />

          <input
            type="tel"
            name="phone"
            placeholder="Phone"
            value={form.phone}
            onChange={handleChange}
            className="w-full border px-4 py-3 rounded-lg"
          />

          <textarea
            name="message"
            placeholder="Message"
            value={form.message}
            onChange={handleChange}
            className="w-full border px-4 py-3 rounded-lg"
          />

          <button
            type="button"
            onClick={handleSubmit}
            disabled={loading}
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 rounded-lg font-semibold"
          >
            {loading ? "Submitting..." : "Submit Request"}
          </button>

        </div>

      </div>
    </section>
  );
}