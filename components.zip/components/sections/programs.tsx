import { ArrowRight } from "lucide-react";

const programs = [
  {
    title: "AI Engineering Bootcamp",
    desc: "Master AI development with hands-on real-world projects.",
  },
  {
    title: "Full Stack + AI",
    desc: "Build scalable apps integrated with AI capabilities.",
  },
  {
    title: "Data Science & ML",
    desc: "Learn data-driven decision making and machine learning.",
  },
];

const Programs = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">

        {/* Heading */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-[#0F172A]">
            Explore Our Programs
          </h2>
          <p className="text-[#64748B] mt-3">
            Industry-focused programs designed to make you job-ready.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-6">

          {programs.map((item, index) => (
            <div
              key={index}
              className="group border border-gray-200 rounded-2xl p-6 bg-white hover:shadow-xl transition-all duration-300"
            >
              {/* Icon */}
              <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gradient-to-r from-purple-500 to-indigo-500 text-white mb-4">
                {index + 1}
              </div>

              {/* Title */}
              <h3 className="text-lg font-semibold text-[#0F172A]">
                {item.title}
              </h3>

              {/* Description */}
              <p className="text-sm text-[#64748B] mt-2">
                {item.desc}
              </p>

              {/* CTA */}
              <div className="mt-4 flex items-center text-purple-600 font-medium text-sm">
                Learn More
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition" />
              </div>
            </div>
          ))}

        </div>
      </div>
    </section>
  );
};

export default Programs;